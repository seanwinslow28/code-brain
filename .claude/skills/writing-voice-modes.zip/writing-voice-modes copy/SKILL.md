---
name: writing-voice-modes
description: Writing voice and tone control calibrated to Sean's personal style. 5 modes — Domestic Observer (Sedaris), Gonzo Technical (Thompson), Beat Flow (Kerouac), Minimalist Absurdist (Vonnegut), and Sean Mode (calibrated hybrid). Use when asked to "write in my voice", "use gonzo mode", "beat flow", "write a blog post" (pairs with creative-writing), "make this sound like me", "add voice to this", "rewrite with personality", or any writing task where tone and style matter.
---

# Writing Voice Modes

## Purpose

Control HOW writing sounds by applying one of 5 voice modes calibrated to Sean Winslow's personal style. This skill works alongside `creative-writing` (format/structure) and `technical-writing` (audience/clarity) — voice modes add personality, rhythm, and tone within those frameworks.

## When to Use

- Writing blog posts, essays, newsletters, or social media with a distinct voice
- Rewriting flat or generic text to sound like Sean
- Choosing which voice mode fits a content type or audience
- Combining techniques from multiple modes for hybrid effects
- Dialing voice intensity up or down for professional vs. personal contexts
- Any writing task where "make this sound like me" is the goal

## Examples

**Example 1: Blog Post in Sean Mode**
```
User: "Write a blog post intro about switching from Zapier to Claude Code"
Claude: [Uses writing-voice-modes — Sean Mode + creative-writing blog template]

I spent eleven months building Zapier workflows with the quiet devotion of
a man assembling IKEA furniture — following instructions I half-understood,
ignoring the leftover pieces, and telling myself it looked right enough.
Thirty-seven zaps. Each one a small miracle of duct tape and prayer,
connecting tools that were never meant to speak to each other, held
together by webhooks and blind optimism. Then I opened a terminal, typed
a prompt, and watched an agent rebuild the entire pipeline in fourteen
minutes. I sat there with my coffee getting cold and my ego getting colder.
The Zapier dashboard is still open in a tab somewhere. I don't visit it
anymore. Agents do.
```

**Example 2: Switching Modes Mid-Piece**
```
User: "Write a post-mortem intro — start Gonzo, land Vonnegut"
Claude: [Uses writing-voice-modes — Thompson cold open → Vonnegut flat collision]

I DEPLOYED TO PRODUCTION at 11:47 PM on a Wednesday because I am a
person who makes decisions like that. The dashboard lit up and started
screeching like the soprano in Pink Floyd's "Great Gig In The Sky" —
847 errors in ninety seconds, each one a small monument to my arrogance.
I mass-Slacked the team. Most of them were asleep. One engineer responded
with a thumbs-up emoji, which I chose to interpret as solidarity.

The rollback took four minutes. The post-mortem took three weeks.
The lesson was simple. I had tested in staging. Staging was wrong.
Production was also wrong, but differently. So it goes with systems
built by humans who believe their own staging environments.
```

**Example 3: Professional Slack (Dialed to 60%)**
```
User: "Write a Slack message about a delayed feature launch"
Claude: [Uses writing-voice-modes — Sean Mode at 60%]

Hey team — quick update on the Campus 201 launch. We're pushing to next
Thursday. The auth flow works perfectly in staging, which historically
means it will find exciting new ways to fail in production. QA caught
two edge cases we hadn't accounted for, so we're fixing those before
we give users the opportunity to find twelve more. I'll update the
timeline in Jira. Holler if questions.
```

## The 5 Voice Modes

### 1. Domestic Observer Mode (Sedaris-tuned)

Sean's **primary texture**. Self-deprecating humor, hyper-specific details, mundane accumulation building toward an unsignposted emotional pivot.

**Core Mechanics:**
- **Loaded sentences:** Front-load the mundane, back-load the surprise. Funniest word lands last.
- **Mundane accumulation → Pivot:** String together light observations, then execute a sharp tonal pivot to something real. Never signpost the pivot.
- **Cold description (defamiliarization):** Strip away a tool's name, describe its literal components. "Every morning, I type my deepest professional insecurities into a blank text box, and a server farm somewhere in Oregon mathematically hallucinates a reassuring response."
- **The adopt-and-corrupt arc:** Adopt technology with enthusiasm → describe in domestic terms → reveal it exposed something about yourself.
- **Sentence-end punchline:** Build a reasonable premise, pivot in the final clause.

**When to deploy:** Personal essays, newsletters, LinkedIn, any piece where humor earns trust before the real point lands.

### 2. Gonzo Technical Mode (Thompson-tuned)

First-person participant-observer-critic. Frame everything as a quest — solving a specific problem, not listing features.

**Core Mechanics:**
- **Cold open:** Drop the reader mid-action. Location + sensory detail + immediate tension. Context arrives later, in fragments.
- **Escalation loop:** Inventory (establish baseline) → Trigger (routine encounter) → Amplification (hyperbole elevates to absurd) → Factual Anchor (exact numbers restore credibility).
- **The triple position:** Participate, observe, critique — simultaneously. Earn the right to observe by participating. Earn the right to critique by observing precisely.
- **Typographic notation:** ALL CAPS for scene kicks. Italics for emotional weight. Em dashes for urgent interruptions.
- **Self-implication:** Criticize the system, but ensure you are the primary victim of your own incompetence within that system.
- **Precision enables wildness:** "412 validation errors cascading down my monitor" is visceral. "A lot of errors" is boring.

**When to deploy:** Blog posts, product reviews, post-mortems, any piece where the writer's experience IS the argument.

### 3. Beat Flow Mode (Kerouac-tuned)

Sean's **sentence engine**. Use for momentum, sensory cascading, and making technical explanations feel alive.

**Core Mechanics:**
- **Dash rhythm:** Em dashes as breath marks between phrases — connecting a technical concept to its human implication in a single breath.
- **Polysyndeton:** Stack "and" to create drumbeat accumulation. Every item gets equal weight. The reader *feels* the complexity.
- **The jewel center:** Anchor abstract concepts to one hyper-specific concrete image (a blinking cursor, a weathered Logitech, a ferry horn). Everything radiates outward from that image.
- **Sensory cascading:** Never write "AI improves productivity." Write the smells, the sounds, the sweat, the pupils dilating.
- **Dual narrator:** Present-self comments on past-self. "I charged forward. That was then." Immediacy AND retrospective humility.

**When to deploy:** Technical explanations that need momentum, personal essays that need emotional buildup, any passage where you need the reader to feel velocity.

### 4. Minimalist Absurdist Mode (Vonnegut-tuned)

Sean's **punctuation toolkit** — deployed in bursts of 3-5 lines, not sustained for whole pieces. Maximum impact through minimum friction.

**Core Mechanics:**
- **Refrains:** Choose a phrase that encapsulates the piece's tension. Deploy after each instance. The phrase accumulates meaning through repetition. Final instance shifts tense or form to resolve ("I began again" → "I have begun").
- **Flat collision:** State a technical capability flatly, collide with irreducible human experience. "The machine had read every book ever written. It still couldn't tell you why your mother was sad."
- **Affirmative constraint:** Say what IS, not what isn't. "Initialize the server first. Then connect." Not "Do not forget to initialize..."
- **Short declaratives for devastation:** After a long flowing passage, a 5-word sentence drops like a hammer. The impact comes from breaking the established rhythm.

**When to deploy:** Closers, one-liners within longer pieces, refrains threaded through an essay, any moment where less hits harder. NOT for sustained use — Sean needs runway.

### 5. Sean Mode (Calibrated Hybrid) — DEFAULT

The natural voice. Load this when no specific mode is requested.

**Base layer:** Sedaris-Thompson — humor, specificity, self-deprecation, self-implication
**Sentence engine:** Kerouac — flowing connective rhythm, sensory anchoring, dash breath marks
**Credibility layer:** Thompson — factual precision (exact numbers, timestamps) dropped AFTER sensory/analogical buildup
**Punctuation:** Vonnegut — refrains as closers, flat one-liners for impact, deployed in bursts

## Sean's Signature Moves

These cross all modes. Apply instinctively.

| Move | Mechanic | Example |
|------|----------|---------|
| **Hard Cut / Deflation** | Build epic or serious, land on mundane/absurd/self-deprecating | "Here's the deal... then we'll burn it all, throw our hands in the air, and question everything." |
| **Rule of Three + Emotional Pivot** | Two concrete/funny items, third pivots to real feeling | "Fuelled by new found skills, fresh brewed coffee, and for once in my life, a glimmer of hope." |
| **Callback Closer** | End by returning to an earlier image, transformed | Ferry → "I hear the ferry horn blast... but I no longer rub elbows with sheep." |
| **Sensory Before Numbers** | Smells, sounds, images FIRST. Numbers confirm. | Nostrils flare, pupils dilate, sweat drips → "847 errors in ninety seconds." |
| **Pop Culture Anchoring** | Movie/TV/meme/music refs in unexpected contexts | Dashboard screeching "like the soprano in Pink Floyd's Great Gig In The Sky" |
| **Hyper-Specific Anecdotes** | So specific the reader pictures it without shared experience | "I haven't squinted this hard since I got drunk in the streets of Phuket on a bucket of vodka redbulls and stumbled into a local bathhouse" |
| **Screenwriting Cut-To** | Hard juxtaposition between expectation and reality | "I'll be taking it easy tonight" *cut to* "SHOVE THE BEER BONG UP MY ASS" |
| **Humor as Trojan Horse** | Serious points arrive inside jokes. Always a release valve. | The werewolf/turning-30 bit — epic setup, mundane punchline ("tired by 6 pm and you think about taxes") |
| **Self-Deprecation as Structure** | Always the biggest fool in the room first | Earns the right to observe others without cruelty |

## Professional Dial

Voice intensity adjusts by context. Sarcasm is ALWAYS present.

| Context | Dial | What Survives | What Stays in the Drawer |
|---------|------|---------------|-------------------------|
| Personal writing | 100% | Everything | Nothing |
| Comfortable colleagues | 80% | Dry humor, pop culture refs, self-deprecation, callbacks | Extreme anecdotes |
| Team Slack / standups | 60% | Structure, dry humor, sarcasm, wit | Silly references, wild anecdotes |
| Stakeholder updates | 40% | Clean structure, occasional dry wit, confident tone | Most humor, all references |
| External / formal | 20% | Clarity, directness, subtle sarcasm undertone | Overt humor, self-deprecation |

## Content Type → Mode Mapping

| Content Type | Primary Mode | Secondary Mode |
|---|---|---|
| Blog post / product review | Thompson (Quest + Cold Open) | Kerouac (dash rhythm) |
| Twitter / LinkedIn / short-form | Sedaris (Rule of Three, punchlines) | Vonnegut (refrains, flat collision) |
| Technical documentation | Vonnegut (Affirmative Constraint, mosaic) | Thompson (factual anchoring) |
| Personal essay / newsletter | Sedaris (Mundane → Pivot) | Kerouac (Dual Narrator, jewel center) |
| Post-mortem / retrospective | Kerouac (Dual Narrator) | Thompson (self-implication) |
| Slack / casual professional | Sean Mode at 60% | Dry humor, structure, no wild refs |
| Conference talk / presentation | Vonnegut (short chips, story shapes) | Sedaris (live-tested timing) |
| Poems / micro-format | Vonnegut (compression) | Sedaris (punchline placement) |

## Complementary Technique Pairs

Use these when combining modes within a single piece.

- **Vonnegut Flat Collision + Thompson Cold Open:** Open mid-action, deliver thesis in flat one-liner. Maximum impact, minimum warmup.
- **Kerouac Dash Rhythm + Thompson Escalation ("The Panicked Architect"):** Breathless momentum + escalating stakes. Use for describing tech failures.
- **Sedaris Mundane Accumulation + Vonnegut Refrain:** Light comedic surface with refrain marking underlying darkness without commenting on it.
- **Thompson Factual Anchoring + Kerouac Dual Narrator:** Trust from two directions — raw competence via numbers + retrospective humility via present-self/past-self.

## Anti-Patterns: When Modes Become Parody

| Mode | Anti-Pattern | The Tell |
|------|-------------|----------|
| Beat Flow | **Bad Kerouac** | Rambling without a jewel center. Dashes everywhere with no rhythmic variation. Long sentences because you can't find the period, not because the thought demands the length. |
| Gonzo Technical | **Bad Thompson** | Chaos without factual anchoring. Criticism without self-implication. Using first-person as an excuse to skip the reporting. Gonzo without journalism is just a tantrum. |
| Minimalist Absurdist | **Bad Vonnegut** | Sustained flatness — Sean needs runway. Copying "So it goes" instead of inventing your own refrain. Short sentences because you have nothing to say. |
| Domestic Observer | **Bad Sedaris** | Self-deprecation sliding to self-pity. Repeating the bit instead of trusting it landed. Punchlines without the mundane accumulation that earns them. |
| Sean Mode | **Bad Sean** | Over-referencing the same sensory detail (coffee appears three times). Too many metaphors stacked without breathing room. Bathroom smell mentioned in every paragraph. One strong reference earns it — three is falling in love with your own material. |

## References

**When matching Sean's voice closely** (blog posts, essays, newsletters), read:
`references/voice-samples.md` — Real writing samples tagged by mode and signature move. The calibration anchors.

**When fine-tuning or debugging voice output**, read:
`references/calibration-notes.md` — Interview findings, mode ranking, key discoveries, and what doesn't work.

**When doing deep craft work or studying author mechanics**, read:
`vault/40_knowledge/references/ref-voice-mechanics-research.md` — Full technique profiles for Kerouac, Thompson, Vonnegut, and Sedaris with transferable techniques.

None of these are needed for standard voice application — the mode descriptions and signature moves in this file are sufficient.

## Related Skills

- `creative-writing` — Owns format/structure (blog templates, social media constraints, pitch docs). Voice modes control HOW content sounds within those formats.
- `technical-writing` — Owns audience/clarity (progressive disclosure, front-loaded conclusions). Voice modes add personality within those constraints.
- `script-writing` — Sean's other medium. The screenwriting cut-to is a signature move that crosses into prose.

## Success Criteria

- [ ] Writing sounds like Sean, not like a generic AI or an author imitation
- [ ] Chosen mode matches the content type and audience
- [ ] Signature moves appear naturally (not forced or checklist-inserted)
- [ ] Professional dial matches the context (no Phuket stories in stakeholder updates)
- [ ] No anti-pattern violations (no Bad Kerouac, Bad Thompson, etc.)
- [ ] Humor serves the point, not the other way around
- [ ] Closers are the strongest line in the piece

## Copy/Paste Ready

```
"Write this in my voice"
"Use Gonzo mode for this blog post"
"Rewrite this in Beat Flow"
"Make this sound like me, dialed to 60%"
"Write a newsletter intro in Sean Mode"
"Apply Domestic Observer to this draft"
"This is too flat — add voice"
```
